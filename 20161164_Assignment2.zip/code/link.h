#ifndef LINK_H
#define LINK_H


class Link
{
public:
    Link();
};

#endif // LINK_H
