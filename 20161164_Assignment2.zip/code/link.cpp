#include "link.h"

Link::Link()
{

}

