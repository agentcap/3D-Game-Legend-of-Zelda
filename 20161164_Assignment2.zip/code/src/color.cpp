#include "main.h"

const color_t COLOR_RED = { 255,0,0 };
const color_t COLOR_GREEN = { 135, 211, 124 };
const color_t COLOR_BLACK = { 0, 0, 0 };
//const color_t COLOR_BLACK = { 52, 73, 94 };
const color_t COLOR_BACKGROUND = { 242, 241, 239 };

const color_t COLOR_BROWN = { 139,69,19 };
const color_t COLOR_WHITE = { 255,255,255 };
const color_t COLOR_YELLOW = { 255,255,0 };
const color_t COLOR_BLUE = { 64, 164, 223};
const color_t COLOR_MAROON = { 128,0,0};
const color_t COLOR_GOLD = { 255,215,0 };
const color_t COLOR_CYAN = { 0,139,139 };
const color_t COLOR_PURPLE = { 128,0,128 };
const color_t COLOR_ORANGE = { 255,165,0 };
